Coloca aquí tu pista: tema.mp3 (opcional tema.ogg). El botón 🎵 activa/pausa y el slider ajusta volumen.
